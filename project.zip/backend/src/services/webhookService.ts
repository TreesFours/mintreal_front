// backend/src/services/webhookService.ts
import crypto from 'crypto';
import { Op } from 'sequelize';
import axios from 'axios';
import * as admin from 'firebase-admin';
import logger from '../utils/logger';
import { User, SocialEvent, sequelize } from '../models/userModel';

export class WebhookService {
// ... (rest of the imports/class structure)
    private static readonly SECRET = process.env.ZERNIO_WEBHOOK_SECRET;
    private static readonly ZERNIO_API_KEY = process.env.ZERNIO_API_KEY || '';

    /**
     * 🛡️ SECURITY: Best-practice HMAC Verification
     * Uses constant-time comparison to prevent timing attacks.
     */
    static verifySignature(payload: string, signature: string): boolean {
        if (!this.SECRET) {
            logger.warn('⚠️ ZERNIO_WEBHOOK_SECRET is not set. Security at risk.');
            return false;
        }

        const hmac = crypto.createHmac('sha256', this.SECRET);
        const digest = hmac.update(payload).digest('hex');

        try {
            return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(digest));
        } catch {
            return false;
        }
    }

    /**
     * 🧠 INNOVATION: Multi-stage Event Orchestration
     * Ensures database integrity using Transactions.
     */
    static async handleEvent(event: any) {
        // 🛡️ ADAPTIVE PAYLOAD RESOLUTION
        // Support both Zernio standard and "Late" (internal engine) payload shapes
        const type = event.event || event.type;
        const data = event.data || event.account || event.message || event.comment;
        const platform = event.platform || data?.platform;

        // Profile ID can be profile_id or profileId (nested or flat)
        const profileId = event.profile_id || event.profileId || data?.profileId || data?.profile_id;

        logger.info(`📨 [ZERNIO WEBHOOK] Type: ${type} | Platform: ${platform} | Profile: ${profileId}`);
        logger.debug(`📄 [RAW PAYLOAD]: ${JSON.stringify(event)}`);

        // Use a transaction to ensure all metadata updates happen atomically
        const transaction = await sequelize.transaction();

        try {
            // 🛡️ SECURITY: Strict Multi-Tenant Lookup
            const user = await User.findOne({
                where: { zernioProfileId: profileId || 'NOT_FOUND' },
                transaction
            });

            if (!user) {
                logger.warn(`⚠️ [ZERNIO] Unauthorized or Orphaned Webhook for profile_id: ${profileId}. Ensure this profileId is mapped to a user in our DB.`);
                await transaction.rollback();
                return;
            }

            logger.info(`👤 [ZERNIO] Event belongs to User: ${user.deviceId} (${user.userName || 'No Name'})`);

            switch (type) {
                case 'message.received':
                case 'message.created':
                    await this.handleIncomingMessage(user, data, platform, transaction);
                    break;
                case 'message.read':
                    await this.handleMessageRead(user, data, platform, transaction);
                    break;
                case 'comment.received':
                case 'comment.created':
                    await this.handleCommentReceived(user, data, platform, transaction);
                    break;
                case 'account.connected':
                    await this.handleAccountConnected(user, data, platform, transaction);
                    break;
                case 'account.disconnected':
                    await this.handleAccountDisconnected(user, data, platform, transaction);
                    break;
                case 'post.published':
                    await this.handlePostPublished(user, data, platform, transaction);
                    break;
                case 'message.sent':
                    await this.handleMessageSent(user, data, platform, transaction);
                    break;
                default:
                    logger.debug(`ℹ️ Passive event ${type} logged for device ${user.deviceId}.`);
            }

            await transaction.commit();
        } catch (error: any) {
            await transaction.rollback();
            logger.error(`❌ Webhook Critical Error: ${error.message}`);
        }
    }

    private static async handleIncomingMessage(user: any, data: any, platform: string, transaction: any) {
        const sender = data.sender?.name || data.sender?.id || "Unknown";

        // 📸 WhatsApp Media Handling: Download and store in Firebase Storage
        if (platform.toLowerCase() === 'whatsapp' && data.attachments) {
            for (const attachment of data.attachments) {
                if (attachment.url && attachment.url.includes('zernio.com')) {
                    try {
                        logger.info(`📥 WhatsApp Media detected: Downloading from ${attachment.url}`);

                        // 1. Download from Zernio
                        const response = await axios.get(attachment.url, {
                            headers: { 'Authorization': `Bearer ${this.ZERNIO_API_KEY}` },
                            responseType: 'arraybuffer'
                        });

                        // 2. Upload to Firebase Storage
                        const bucket = admin.storage().bucket();
                        const fileName = `media/${user.deviceId}/${Date.now()}_${attachment.id || 'file'}`;
                        const file = bucket.file(fileName);

                        const contentType = response.headers['content-type']?.toString() || 'application/octet-stream';

                        await file.save(Buffer.from(response.data), {
                            metadata: { contentType: contentType }
                        });

                        // 3. Make public or get Signed URL
                        await file.makePublic();
                        attachment.url = `https://storage.googleapis.com/${bucket.name}/${fileName}`;

                        logger.info(`✅ WhatsApp Media secured: ${attachment.url}`);
                    } catch (e: any) {
                        logger.error(`❌ Media Download/Upload failed: ${e.message}`);
                    }
                }
            }
        }

        // 💾 PERSISTENCE: Save to SocialEvent table for feed and history
        await SocialEvent.create({
            deviceId: user.deviceId,
            platform: platform.toLowerCase(),
            type: 'message',
            externalId: data.message_id || data.id || `msg_${Date.now()}`,
            senderId: data.sender?.id,
            senderName: sender,
            content: data.content?.text || data.text || "",
            metadata: {
                attachments: data.attachments || [],
                conversationId: data.conversationId
            },
            timestamp: new Date(),
            isRead: false
        }, { transaction });

        // Update unread count atomically
        user.unreadMessagesCount = (user.unreadMessagesCount || 0) + 1;

        const unreadMetadata = { ...(user.preferences?.unreadMetadata || {}) };
        const platformKey = platform.toLowerCase();
        if (!unreadMetadata[platformKey]) unreadMetadata[platformKey] = [];

        // 🚀 INNOVATION: Context-Aware Payload
        unreadMetadata[platformKey].push({
            id: data.message_id,
            type: 'message',
            sender: sender,
            content: data.content,
            timestamp: new Date().toISOString(),
            is_priority: data.content?.toLowerCase().includes('urgent') || false
        });

        user.set('preferences', { ...user.preferences, unreadMetadata });
        user.changed('preferences', true);
        await user.save({ transaction });

        logger.info(`💬 [${platform}] Message queued for Shadow AI analysis.`);
    }

    private static async handleMessageRead(user: any, data: any, platform: string, transaction: any) {
        if (user.unreadMessagesCount > 0) {
            user.unreadMessagesCount -= 1;

            const unreadMetadata = { ...(user.preferences?.unreadMetadata || {}) };
            const platformKey = platform.toLowerCase();
            if (unreadMetadata[platformKey]) {
                unreadMetadata[platformKey] = unreadMetadata[platformKey].filter((m: any) => m.id !== data.message_id);
                user.set('preferences', { ...user.preferences, unreadMetadata });
                user.changed('preferences', true);
            }

            await user.save({ transaction });
        }
    }

    private static async handleCommentReceived(user: any, data: any, platform: string, transaction: any) {
        // 💾 PERSISTENCE: Save to SocialEvent table
        await SocialEvent.create({
            deviceId: user.deviceId,
            platform: platform.toLowerCase(),
            type: 'comment',
            externalId: data.comment_id || `comment_${Date.now()}`,
            senderId: data.author?.id,
            senderName: data.author?.name || "Unknown",
            content: data.content || "",
            metadata: {
                post_id: data.post_id
            },
            timestamp: new Date(),
            isRead: false
        }, { transaction });

        const unreadMetadata = { ...(user.preferences?.unreadMetadata || {}) };
        const platformKey = platform.toLowerCase();
        if (!unreadMetadata[platformKey]) unreadMetadata[platformKey] = [];

        unreadMetadata[platformKey].push({
            id: data.comment_id,
            type: 'comment',
            sender: data.author?.name || "Unknown",
            content: data.content,
            post_id: data.post_id,
            timestamp: new Date().toISOString()
        });

        user.set('preferences', { ...user.preferences, unreadMetadata });
        user.changed('preferences', true);
        await user.save({ transaction });
    }

    private static async handleIncomingCall(user: any, data: any, platform: string, transaction: any) {
        const caller = data.caller?.name || data.caller?.id || "Unknown Caller";
        const unreadMetadata = { ...(user.preferences?.unreadMetadata || {}) };

        unreadMetadata['system_alerts'] = unreadMetadata['system_alerts'] || [];
        unreadMetadata['system_alerts'].push({
            id: data.call_id,
            type: 'call_incoming',
            platform,
            sender: caller,
            timestamp: new Date().toISOString(),
            action_required: 'BRIEFING'
        });

        user.set('preferences', { ...user.preferences, unreadMetadata });
        user.changed('preferences', true);
        await user.save({ transaction });
        logger.info(`📞 [${platform}] Alerting Shadow AI of incoming call from ${caller}`);
    }

    private static async handleCallEnded(user: any, data: any, platform: string, transaction: any) {
        const unreadMetadata = { ...(user.preferences?.unreadMetadata || {}) };
        unreadMetadata['system_alerts'] = unreadMetadata['system_alerts'] || [];

        unreadMetadata['system_alerts'].push({
            id: data.call_id,
            type: 'call_ended',
            platform,
            duration: data.duration_seconds,
            timestamp: new Date().toISOString(),
            action_required: 'SUMMARY'
        });

        user.set('preferences', { ...user.preferences, unreadMetadata });
        user.changed('preferences', true);
        await user.save({ transaction });
    }

    private static async handleWhatsAppTemplateUpdate(user: any, data: any, transaction: any) {
        const unreadMetadata = { ...(user.preferences?.unreadMetadata || {}) };
        unreadMetadata['system_alerts'] = unreadMetadata['system_alerts'] || [];

        unreadMetadata['system_alerts'].push({
            type: 'whatsapp_business',
            template_name: data.template_name,
            status: data.status,
            timestamp: new Date().toISOString()
        });

        user.set('preferences', { ...user.preferences, unreadMetadata });
        user.changed('preferences', true);
        await user.save({ transaction });
    }

    private static async handleAccountConnected(user: any, data: any, platform: string, transaction: any) {
        const connected = user.connectedPlatforms || [];
        if (!connected.includes(platform.toLowerCase())) {
            connected.push(platform.toLowerCase());
            user.connectedPlatforms = connected;
            await user.save({ transaction });
            logger.info(`✅ [${platform}] Account connection secured via Webhook.`);
        }
    }

    private static async handleAccountDisconnected(user: any, data: any, platform: string, transaction: any) {
        const connected = user.connectedPlatforms || [];
        user.connectedPlatforms = connected.filter((p: string) => p !== platform.toLowerCase());
        await user.save({ transaction });
        logger.warn(`🛑 [${platform}] Account disconnected via Webhook.`);
    }

    private static async handlePostPublished(user: any, data: any, platform: string, transaction: any) {
        // 💾 PERSISTENCE: Save our own published post to the flow
        await SocialEvent.create({
            deviceId: user.deviceId,
            platform: platform.toLowerCase(),
            type: 'post',
            externalId: data.post_id || `post_${Date.now()}`,
            senderId: 'self',
            senderName: user.userName || 'Me',
            content: data.content || "",
            metadata: {
                url: data.url
            },
            timestamp: new Date(),
            isRead: true
        }, { transaction });

        logger.info(`🚀 [${platform}] Post successfully published and persisted.`);
    }

    private static async handleMessageSent(user: any, data: any, platform: string, transaction: any) {
        // 💾 PERSISTENCE: Save our own outgoing message to history
        await SocialEvent.create({
            deviceId: user.deviceId,
            platform: platform.toLowerCase(),
            type: 'message',
            externalId: data.message_id || data.id || `sent_${Date.now()}`,
            senderId: 'self',
            senderName: user.userName || 'Me',
            content: data.content?.text || data.text || "",
            metadata: {
                attachments: data.attachments || [],
                recipientId: data.recipientId,
                conversationId: data.conversationId
            },
            timestamp: new Date(),
            isRead: true
        }, { transaction });

        logger.info(`📤 [${platform}] Outgoing message persisted to history.`);
    }
}
