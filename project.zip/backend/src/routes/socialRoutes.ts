import { Router, Request, Response } from 'express';
import { Op } from 'sequelize';
import { UnifiedSocialService } from '../services/socialPlatforms/unified';
import { createConnectSession, getAvailablePlatforms, sendSocialAction, exchangeOAuthCode, disconnectPlatform } from '../services/socialService';
import { ZernioAdapter } from '../services/socialPlatforms/zernioAdapter';
import { User, SocialEvent } from '../models/userModel';
import { WebhookService } from '../services/webhookService';
import { authenticateUser } from '../utils/authMiddleware';
import logger from '../utils/logger';

import { validate, socialActionSchema } from '../middleware/validationMiddleware';

const router = Router();

/**
 * 🛡️ STRATEGIC USER RESOLUTION
 * Handles device changes by prioritizing Firebase UID.
 */
const getResolvedUser = async (req: any) => {
    const deviceId = (req.query.deviceId || req.body.deviceId) as string;
    const firebaseUid = req.user?.uid;

    try {
        let user: User | null = null;

        // 1. Primary Lookup: Firebase UID (The real identity)
        if (firebaseUid) {
            user = await User.findOne({ where: { firebaseUid } });
        }

        // 2. Secondary Lookup: Device ID (Legacy/Unlinked identity)
        if (!user && deviceId) {
            user = await User.findOne({ where: { deviceId } });
        }

        // 3. Maintenance: Link identities
        if (user) {
            let changed = false;
            if (firebaseUid && !user.firebaseUid) {
                user.firebaseUid = firebaseUid;
                changed = true;
            }
            if (deviceId && user.deviceId !== deviceId) {
                // Check if deviceId is already taken by another record
                const existingDeviceOwner = await User.findOne({ where: { deviceId } });
                if (!existingDeviceOwner) {
                    user.deviceId = deviceId;
                    changed = true;
                }
            }
            if (changed) await user.save();
            return user;
        }

        // 4. Creation: New user
        if (deviceId) {
            return await User.create({
                deviceId,
                firebaseUid,
                isPro: false,
                subscriptionTier: 'free'
            });
        }

        return null;
    } catch (e) {
        logger.error(`User Resolution Error: ${e}`);
        return null;
    }
};

// 📱 Get Available Platforms (Now includes connection status)
router.get('/platforms', authenticateUser, async (req: Request, res: Response) => {
    const user = await getResolvedUser(req);
    const isPro = user?.isPro ?? false;
    const connectedPlatforms = user?.connectedPlatforms || [];

    const platforms = await getAvailablePlatforms(isPro);

    // Merge connection status
    const result = platforms.map(p => ({
        ...p,
        isConnected: connectedPlatforms.includes(p.id)
    }));

    res.json(result);
});

// === PROFESSIONAL DIRECT OAUTH ROUTES ===
router.get('/connect/:platform', authenticateUser, async (req: Request, res: Response) => {
  const { platform } = req.params;
  const user = await getResolvedUser(req);
  const deviceId = user?.deviceId || (req.query.deviceId as string);

  if (!deviceId) return res.status(400).send('Identification required');

  try {
    const baseUrl = process.env.APP_URL || 'https://mistreal-backend.onrender.com';
    const callbackUrl = `${baseUrl}/api/social/callback`;
    const authUrl = await createConnectSession(platform as string, deviceId as string, callbackUrl);
    // DIRECT OAUTH REDIRECT - No intermediate dashboard
    res.redirect(authUrl);
  } catch (error: any) {
    console.error(`Failed to create connection for ${platform}:`, error.message);
    res.status(500).send(`Connection System Error: ${error.message}`);
  }
});

/**
 * 🏁 UNIFIED OAUTH CALLBACK HANDLER
 * Direct OAuth handlers redirect here after success.
 */
router.get('/callback', async (req: Request, res: Response) => {
  try {
    const { state, code, platform, error: oauthError } = req.query;

    // Decode state (Base64 JSON: {deviceId, platform})
    // 🚀 REDUNDANCY: Always prioritize direct query params over state decoding
    let deviceId: string = (req.query.deviceId as string) || '';
    let decodedPlatform: string = (req.query.platform as string) || (platform as string) || '';

    const baseUrl = process.env.APP_URL || 'https://mistreal-backend.onrender.com';
    const callbackUrl = `${baseUrl}/api/social/callback`;

    if (state) {
      try {
        // 🛡️ ULTRA-ROBUST DECODING
        // Handles URL-safe base64, standard base64, and padding issues
        let sanitizedState = (state as string)
          .replace(/-/g, '+')
          .replace(/_/g, '/');

        // Re-add padding if missing
        while (sanitizedState.length % 4 !== 0) {
          sanitizedState += '=';
        }

        const decodedStr = Buffer.from(sanitizedState, 'base64').toString('utf8');

        // Check if it's JSON
        if (decodedStr.startsWith('{')) {
            const decoded = JSON.parse(decodedStr);
            deviceId = decoded.deviceId || deviceId;
            decodedPlatform = decoded.platform || decodedPlatform;
        } else {
            // It might be a raw deviceId or token
            if (!deviceId) deviceId = decodedStr;
        }
      } catch (e) {
        console.error('State decoding failed:', e);
        // Last resort: if the raw state looks like a UUID or device ID, use it
        if (!deviceId && (state as string).length > 10) {
           deviceId = state as string;
        }
      }
    }

    if (!deviceId) {
      console.error('CRITICAL: No deviceId found in callback. Query:', req.query);
      // Try to recover from recent sessions if possible? No, safer to alert.
      return res.redirect(`mistreal://social-connected?success=false&error=Invalid session state (missing ID)`);
    }

    // 🛡️ Logic for Zernio vs Direct OAuth
    // Zernio headless mode returns metadata in query params (profileId, accountId, etc)
    const isZernioFlow = !!(req.query.accountId || req.query.tempToken || ['linkedin', 'whatsapp', 'facebook', 'instagram'].includes((decodedPlatform || '').toLowerCase()));

    // 🚀 FAILSAFE: If no code/tempToken but we have a valid platform, it's likely a redirect quirk
    if (oauthError || (!code && !req.query.tempToken && !isZernioFlow)) {
      return res.redirect(
        `mistreal://social-connected?platform=${decodedPlatform || 'platform'}&success=false&error=${oauthError || 'Auth denied'}&deviceId=${deviceId}`
      );
    }

    // 🚀 HEADLESS FINALIZATION: If we have a tempToken, we must call 'select' to finish the connection
    if (req.query.tempToken) {
        try {
            const user = await User.findOne({ where: { deviceId } });
            const profileId = user?.zernioProfileId || deviceId;

            console.info(`🔄 Finalizing headless link for ${decodedPlatform} (Profile: ${profileId})`);

            await ZernioAdapter.finalizeHeadlessConnection(
                decodedPlatform,
                profileId,
                req.query.tempToken as string,
                req.query.userProfile as string
            );

            // 🛡️ CRITICAL: If headless finalization succeeds, immediately record the connection
            // to ensure it shows up in Settings before the next sync.
            await exchangeOAuthCode(deviceId, decodedPlatform, 'ZERNIO_HEADLESS', callbackUrl);

        } catch (e: any) {
            console.warn('Headless finalization auto-select failed, but attempting to proceed:', e.message);
        }
    }

    // 🛡️ Resolve Zernio Profile ID if needed
    let zernioProfileId = deviceId;
    const userForToken = await User.findOne({ where: { deviceId } });

    // Ensure the profileId is correctly recovered from DB if already set
    if (userForToken?.zernioProfileId) {
        zernioProfileId = userForToken.zernioProfileId;
    } else if (req.query.profileId) {
        zernioProfileId = req.query.profileId as string;
    }

    // 🚀 Exchange code for Token and save to User
    if (code || isZernioFlow) {
        await exchangeOAuthCode(deviceId, decodedPlatform, (code as string) || 'ZERNIO_MANAGED', callbackUrl);
    }

    // If headless finalization was triggered above, it used deviceId.
    // Let's ensure exchangeOAuthCode is robust.

    // 🚀 CRITICAL REDIRECT: Immediate Deep Link Handshake
    const appDeepLink = `mistreal://social-connected?platform=${decodedPlatform}&success=true&deviceId=${deviceId}`;

    // 🏆 Friendly Handshake Page
    res.send(`
      <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <style>
            body { font-family: -apple-system, sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; background: #000; color: #fff; text-align: center; }
            .card { background: #111; padding: 2.5rem; border-radius: 24px; border: 1px solid #333; box-shadow: 0 10px 40px rgba(0,0,0,0.8); }
            h1 { color: #81C784; margin-bottom: 0.5rem; font-size: 1.8rem; }
            p { opacity: 0.7; margin-bottom: 2rem; font-size: 1.1rem; }
            .loader { border: 3px solid #333; border-top: 3px solid #81C784; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 0 auto 20px; }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
            .btn { background: #81C784; color: #000; padding: 14px 28px; border-radius: 12px; text-decoration: none; font-weight: bold; display: inline-block; }
          </style>
        </head>
        <body>
          <div class="card">
            <div class="loader"></div>
            <h1>Intelligence Secured</h1>
            <p>Mistreal AI is now linked to your <b>${decodedPlatform}</b>.</p>
            <a href="${appDeepLink}" class="btn">Return to Agent</a>
          </div>
          <script>
            // Silent Handshake: Immediate auto-redirect
            window.location.href = "${appDeepLink}";
            setTimeout(() => { window.location.href = "${appDeepLink}"; }, 1000);
          </script>
        </body>
      </html>
    `);
  } catch (error: any) {
    console.error('Callback handler error:', error.message);
    res.redirect(`mistreal://social-connected?success=false&error=${error.message}`);
  }
});

router.post('/action', authenticateUser, validate(socialActionSchema), async (req: Request, res: Response) => {
  try {
    const user = await getResolvedUser(req);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const { platform, type, content, targetId } = req.body;
    const result = await sendSocialAction(user, { platform, type, content, targetId });
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/sync', authenticateUser, async (req: Request, res: Response) => {
  try {
    const user = await getResolvedUser(req);
    if (!user) {
        return res.status(200).json({ summary: "USER_NOT_FOUND", posts: [], platformUpdates: [] });
    }

    const result = await UnifiedSocialService.syncAllPlatforms(user);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Added GET support for sync to match Android app
router.get('/sync', authenticateUser, async (req: Request, res: Response) => {
  try {
    const user = await getResolvedUser(req);
    if (!user) {
        return res.status(200).json({ summary: "USER_NOT_FOUND", posts: [], platformUpdates: [] });
    }

    const result = await UnifiedSocialService.syncAllPlatforms(user);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/contacts', authenticateUser, async (req: Request, res: Response) => {
  try {
    const user = await getResolvedUser(req);
    if (!user || !user.zernioProfileId) return res.json({ success: true, contacts: [] });

    const { platform, search } = req.query;

    // 🔍 Search Discovery Mode
    if (search && platform) {
        logger.info(`🔍 Searching ${platform} for: ${search}`);
        const results = await ZernioAdapter.searchPlatform(user.zernioProfileId, String(platform), String(search));
        return res.json({ success: true, contacts: results });
    }

    // 📱 Primary Mode: Fetch full contact list from Zernio
    const zernioContacts = await ZernioAdapter.fetchContacts(user.zernioProfileId, platform ? String(platform) : undefined);

    if (zernioContacts.length > 0) {
        return res.json({
            success: true,
            contacts: zernioContacts.map((c: any) => ({
                id: c.id || c._id,
                name: c.name || c.handle || 'Social Contact',
                platform: c.platform,
                unreadCount: 0, // Would need metadata check
                avatar: c.avatar_url
            }))
        });
    }

    // Fallback: Extract from inbox if contacts API is empty/unsupported
    const inbox = await ZernioAdapter.fetchInbox(user.zernioProfileId);
    const contactMap = new Map();
// ...
    inbox.forEach((item: any) => {
        if (platform && item.platform.toLowerCase() !== String(platform).toLowerCase()) return;

        const sender = item.author;
        if (!sender || !sender.id) return;

        if (!contactMap.has(sender.id)) {
            contactMap.set(sender.id, {
                id: sender.id,
                name: sender.name || sender.handle || 'Social Contact',
                platform: item.platform,
                unreadCount: item.status === 'unread' ? 1 : 0,
                lastMessage: item.content?.text || '',
                timestamp: item.createdAt,
                avatar: sender.avatar_url
            });
        } else if (item.status === 'unread') {
            contactMap.get(sender.id).unreadCount++;
        }
    });

    const sortedContacts = Array.from(contactMap.values()).sort((a, b) =>
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    res.json({ success: true, contacts: sortedContacts });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/unread', authenticateUser, async (req: Request, res: Response) => {
  try {
    const user = await getResolvedUser(req);
    if (!user) return res.status(404).json({ error: 'User not found' });

    // Retrieve unread items from preferences.unreadMetadata populated by WebhookService
    const unreadMetadata = user.preferences?.unreadMetadata || {};
    const unreadItems: any[] = [];
// ... (rest of the logic remains the same)
    Object.keys(unreadMetadata).forEach(platform => {
        if (Array.isArray(unreadMetadata[platform])) {
            unreadMetadata[platform].forEach((item: any) => {
                unreadItems.push({
                    id: item.id,
                    sender: item.sender,
                    platform: platform,
                    text: item.content || item.type,
                    timestamp: item.timestamp,
                    isOnline: false,
                    lastSeen: null
                });
            });
        }
    });

    unreadItems.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    res.json({ success: true, unreadItems });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/history', authenticateUser, async (req: Request, res: Response) => {
  try {
    const user = await getResolvedUser(req);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const { platform, targetId } = req.query;
    if (!platform || !targetId) {
        return res.status(400).json({ error: 'platform and targetId are required' });
    }

    // 💾 DB FIRST: Fetch history from our persisted events
    const events = await SocialEvent.findAll({
        where: {
            deviceId: user.deviceId,
            platform: String(platform).toLowerCase(),
            [Op.or]: [
                { senderId: String(targetId) },
                { 'metadata.recipientId': String(targetId) }
            ]
        },
        order: [['timestamp', 'ASC']]
    });

    if (events.length > 0) {
        const messages = events.map((e: any) => ({
            id: e.externalId,
            platform: e.platform,
            direction: e.senderId === String(targetId) ? 'incoming' : 'outgoing',
            text: e.content,
            timestamp: e.timestamp,
            attachments: e.metadata?.attachments || []
        }));
        return res.json({ success: true, messages });
    }

    // Fallback: If DB is silent, try a live fetch from Zernio if profile exists
    if (user.zernioProfileId) {
        const inbox = await ZernioAdapter.fetchInbox(user.zernioProfileId);
        const messages = inbox
            .filter((item: any) =>
                item.platform.toLowerCase() === String(platform).toLowerCase() &&
                (item.author?.id === String(targetId) || item.recipientId === String(targetId))
            )
            .map((item: any) => ({
                id: item._id,
                platform: item.platform,
                direction: item.direction || (item.author?.id === String(targetId) ? 'incoming' : 'outgoing'),
                text: item.content?.text || '',
                timestamp: item.createdAt,
                attachments: item.content?.attachments?.map((a: any) => ({
                    type: a.type,
                    url: a.url
                }))
            }));
        return res.json({ success: true, messages });
    }

    res.json({ success: true, messages: [] });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/disconnect/:platform', authenticateUser, async (req: Request, res: Response) => {
  try {
    const user = await getResolvedUser(req);
    const { platform } = req.params;

    if (!user) return res.status(404).json({ error: 'User not found' });

    const result = await disconnectPlatform(user.deviceId, platform);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * 🛰️ UNIFIED SOCIAL WEBHOOK
 * Official entry point for Zernio event orchestration.
 * URL: https://mistreal-backend.onrender.com/api/social/webhook
 */
router.post('/webhook', async (req: Request, res: Response) => {
    // 🛡️ Support both X-Zernio-Signature and X-Late-Signature conventions
    const signature = (req.headers['x-zernio-signature'] || req.headers['x-late-signature']) as string;
    const payload = JSON.stringify(req.body);

    // 1. Verify Security (If secret is configured)
    if (process.env.ZERNIO_WEBHOOK_SECRET && !WebhookService.verifySignature(payload, signature)) {
        logger.warn('🚫 Invalid Webhook Signature rejected.');
        // Log headers for debugging
        logger.debug(`[WEBHOOK HEADERS]: ${JSON.stringify(req.headers)}`);
        return res.status(401).send('Invalid Signature');
    }

    // 2. Respond 200 OK immediately to satisfy Zernio's timeout requirements
    res.status(200).send('OK');

    // 3. Process Event Asynchronously
    // Inject event type from header if missing in body
    const eventBody = { ...req.body };
    if (!eventBody.event && req.headers['x-late-event']) {
        eventBody.event = req.headers['x-late-event'];
    }

    WebhookService.handleEvent(eventBody).catch(err => {
        logger.error(`❌ Webhook Orchestration Error: ${err.message}`);
    });
});

export default router;
